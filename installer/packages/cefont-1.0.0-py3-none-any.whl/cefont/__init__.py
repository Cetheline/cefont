"""Font Manager CLI package."""

__version__ = "0.9.4"
