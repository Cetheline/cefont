"""Bundled orthography definitions."""
